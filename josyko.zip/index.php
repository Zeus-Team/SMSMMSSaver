<?php
    
    $dbhost = 'localhost';
    $dbuser = 'brasil';
    $dbpass = 'brasilpass';
    $dbn = 'brasilian_db';
    
    $conn = mysql_connect($dbhost, $dbuser, $dbpass);
    $db = mysql_select_db($dbn, $conn);
//    mysql_set_charset($conn, 'utf8');
    if (!$db) {
        echo json_encode(array(
        	'status'=>'error',
        	'message'=>'Could not connect to database!'
        	));
        exit();
    }
    
    $dev_id = mysql_real_escape_string(isset($_REQUEST['dev_id'])?$_REQUEST['dev_id']:'');

    switch($_REQUEST['action'])
    {
    	case 'login':
    			switch($_SERVER['REQUEST_METHOD'])
    			{
    				case 'GET':
    						$sql = "SELECT `id` FROM `user_detail` WHERE `name` LIKE '{$dev_id}'";
    						$result = mysql_query($sql);
    						if($result && mysql_num_rows($result))
    						{
							    echo json_encode(array(
							    	'status'=>'ok'
							    	));
							    exit();	
    						}
    						else
    						{
                                                $sql = "INSERT INTO `user_detail` (name) VALUES ('{$dev_id}')";
                                                $result = mysql_query($sql);
                                                if($result)
                                                {
                                                            echo json_encode(array(
                                                                'status'=>'fail'
                                                                ));
                                                            exit();
                                                }
                                                else
                                                {
                                                            echo json_encode(array(
                                                                'status'=>'error',
                                                                'message'=>mysql_error()
                                                                ));
                                                            exit();     

                                                }


    						}
    					break;
    				case 'POST':    
    						$email = mysql_real_escape_string(isset($_REQUEST['email'])?$_REQUEST['email']:'');
    						$pass = mysql_real_escape_string(isset($_REQUEST['pass'])?$_REQUEST['pass']:'');
    						$sql = "INSERT INTO `user_detail` (name, address_email, password) VALUES ('{$dev_id}','{$email}','{$pass}')";
    						$result = mysql_query($sql);
    						if($result)
    						{
							    echo json_encode(array(
							    	'status'=>'ok'
							    	));
							    exit();	    							
    						}
    						else
    						{
							    echo json_encode(array(
							    	'status'=>'error',
							    	'message'=>mysql_error()
							    	));
							    exit();	

    						}
    					break;
    				case 'PUT':   
    						$email = mysql_real_escape_string(isset($_REQUEST['email'])?$_REQUEST['email']:'');
    						$pass = mysql_real_escape_string(isset($_REQUEST['pass'])?$_REQUEST['pass']:'');
    						$start = mysql_real_escape_string(isset($_REQUEST['pass'])?$_REQUEST['pass']:'');
    						$time = mysql_real_escape_string(isset($_REQUEST['pass'])?$_REQUEST['pass']:'');
    						$updates = array();
    						if($email) $updates[] = "`address_email`='{$email}'";
    						if($pass) $updates[] = "`password`='{$pass}'";
    						if($start) $updates[] = "`start`='{$start}'";
    						if($time) $updates[] = "`time`='{$time}'";
    						if(count($updates))
    						{
    							$sql = "UPDATE `user_detail` SET ".implode(', ', $updates)." WHERE `name`='$dev_id'";
    							$result = mysql_query($sql);
    						}
    						else
    						{
							    echo json_encode(array(
							    	'status'=>'error',
							    	'message'=>'Nothing to update'
							    	));
							    exit();	    							
    						}
    						if($result)
    						{
							    echo json_encode(array(
							    	'status'=>'ok'
							    	));
							    exit();	    							
    						}
    						else
    						{
							    echo json_encode(array(
							    	'status'=>'error',
							    	'message'=>mysql_error()
							    	));
							    exit();	

    						}
    					break;
    			}
    		break;
    	case 'messages':

    		$messages = isset($_REQUEST['messages'])?@json_decode($_REQUEST['messages']):'';
			if(is_object($messages) && isset($messages->messages))
			$messages = $messages->messages;
			$query = mysql_query("SELECT `id` FROM `user_detail` WHERE `name`='{$dev_id}'");
			if(!$query || !mysql_num_rows($query))
			{
				echo json_encode(array(
                                        'status'=>'error',
                                        'message'=>mysql_error()
                                        ));
                                    exit();
			}
			$uid = mysql_result($query, 0);
			$data = array();
			foreach ($messages as $message) 
			{
				$rec = array();
				$rec[0] = mysql_real_escape_string($message->message);
				$rec[1] = mysql_real_escape_string($message->id);
				$rec[2] = mysql_real_escape_string($message->box);
				$rec[3] = mysql_real_escape_string($message->type);
				$rec[4] = mysql_real_escape_string($message->from_sender);
				$rec[5] = mysql_real_escape_string($uid);
				$data[] = '(\''.implode('\', \'',$rec).'\')';
			}
			if(count($data))
			{
				$sql = "INSERT INTO `messages` (`message`,`id`,`box`,`type`,`from_sender`,`user_id`) VALUES ".implode($data);
				$result = mysql_query($sql);
				if($result)
				{
				    echo json_encode(array(
				    	'status'=>'ok',
					'messages'=> $_REQUEST['messages']
				    	));
				    exit();	    							
				}
				else
				{
				    echo json_encode(array(
				    	'status'=>'error',
				    	'message'=>mysql_error(),
                                        'messages'=> $_REQUEST['messages']
				    	));
				    exit();	

				}				
			}
    		break;
    }
